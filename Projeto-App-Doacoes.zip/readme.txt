It was developed based on the abnTeX2 article template, available at <http://www.abntex.net.br/>, as well as several code snippets developed by TeX-LaTeX Stack Exchange users, available at <http://tex.stackexchange.com/>.

Status: added by Matte J., maintenance on demand.
Last updated: December 5, 2019 (Version 1.2).


Este modelo LaTeX (não oficial) permite a produção de artigo da Universidade do Oeste de Santa Catarina (UNOESC), nos cursos de Sistemas de Informação e Engenharia de Computação

Foi desenvolvido baseado no modelo de artigo abnTeX2, disponível em <http://www.abntex.net.br/>, bem como em diversos trechos de códigos desenvolvidos por usuários do TeX-LaTeX Stack Exchange, disponível em <http://tex.stackexchange.com/>.

Estado: adicionado por Matte J., manutenção sob demanda.
Última atualização: 3 de Março de 2023 (Versão 1.2).
